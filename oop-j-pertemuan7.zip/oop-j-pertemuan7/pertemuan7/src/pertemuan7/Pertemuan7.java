/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan7;

/**
 *
 * @author suciantari
 * TGL: 29-04-2025
 */
public class Pertemuan7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mahasiswa mhs = new mahasiswa();
        mhs.datamhs();
        mhs.datamhs("2301010425");
        mhs.datamhs("2301010425","Suciantari");
        
    }
    
}
