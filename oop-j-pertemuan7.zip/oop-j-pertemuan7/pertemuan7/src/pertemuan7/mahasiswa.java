/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuan7;

/**
 *
 * @author suciantari
 * TGL : 29-04-2025
 */
public class mahasiswa {
    private String NIM, NAMA;
    
    public void datamhs(){
       System.out.println ("Saya Sudah Menyerah") ;
    }
    public void datamhs(String nimm){
        this.NIM=nimm;
       System.out.printf ("Saya Sudah Menyerah %s\n", this.NIM) ;
    }
    public void datamhs(String nimm, String namaa){
        this.NIM=nimm;
        this.NAMA=namaa;
       System.out.printf ("Data Mahasiswa dengan NIM %s adalah %s\n",this.NIM,this.NAMA) ;
    }
}
